define([],function(){
	return {
		name : "Magesh",
		isValid : true
	};
});